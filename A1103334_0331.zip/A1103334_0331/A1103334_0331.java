import java.util.Scanner;

public class A1103334_0331 {
    public static void main(String[] args) {
        animal.showinfo();

        
        animal A = new animal("A", 1.1, 52, 100);
        animal B = new animal("B", 1.5, 99, 200);
        human C = new human("C", 1.9, 80, 150, "Male");
        human D = new human("D", 1.8, 78, 130, "Male");
        human E = new human("E", 1.7, 48, 120, "Female");
        snow F = new snow("F", 1.7, 50, 120, "Female", "YES");

        
        A.show();
        System.out.println();
        B.show();
        System.out.println();
        C.show();
        System.out.println();
        D.show();
        System.out.println();
        E.show();
        System.out.println();
        F.show();
        System.out.println();
        
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter X and Y values for A : ");
        int xA = scanner.nextInt();
        double yA = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance1 = A.distance(xA, yA);
        System.out.println("Total running distance of xuebao is : " + distance1 + " km");

        System.out.print("Enter X and Y values for B : ");
        int xB = scanner.nextInt();
        double yB = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance2 = B.distance(xB, yB);
        System.out.println("Total running distance of eggplant is : " + distance2 + " km");

        System.out.print("Enter X and Y values for C : ");
        int xC = scanner.nextInt();
        double yC = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance3 = C.distance(xC, yC);
        System.out.println("Total running distance of ake is : " + distance3 + " km");

        System.out.print("Enter X and Y values for D : ");
        int xD = scanner.nextInt();
        double yD = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance4 = C.distance(xD, yD);
        System.out.println("Total running distance of hans is : " + distance4 + " km");

        System.out.print("Enter X and Y values for E : ");
        int xE = scanner.nextInt();
        double yE = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance5 = C.distance(xE, yE);
        System.out.println("Total running distance of anna is : " + distance5 + " km");

        System.out.print("Enter X and Y values for F : ");
        int xF = scanner.nextInt();
        double yF = scanner.hasNextDouble() ? scanner.nextDouble() : 1.0;
        double distance6 = C.distance(xF, yF);
        System.out.println("Total running distance of aisha is : " + distance6 + " km");
    }
}
